import java.net.*;
import java.io.*;
import java.util.*;
import java.security.MessageDigest;

public class servThread implements Runnable{
	private Socket socket;
	
	
	public servThread(Socket sock){  this.socket = sock;  }


	public Socket getSocket(){  return this.socket;  }

	
	private String help(){  return serveurTCP.man;  }
		
	
	private synchronized String show_announces(){
	//----Affiche les annonces----
		String res = "";
		for(String ann : serveurTCP.announces){
			String[] spl = ann.split("%%");
			String adre = spl[0], id = spl[1], port = spl[2], titre = spl[3], data = spl[4];
			if(serveurTCP.containsAddr(adre) ){
				res += "ADD ID "+id+" -- TITLE "+titre+"@";
			}
		}
		if(res.equals("")){res = "Pas d'annonces !@";}
		return res;
	}
	
	
	private synchronized String des_announce(String idm){
	//----Affiche une annonce complète----
		String res = "DES@";
		try{
			for(String ann : serveurTCP.announces){
					String[] spl = ann.split("%%");
					String adre = spl[0], id = spl[1], port = spl[2], titre = spl[3], data = spl[4];
					if(id.equals(idm)){			
						res += "ID : "+id+"@Titre : "+titre+"@Description : "+data+"@Envoyé par "+adre+" -- Port de connexion : "+port+"@@";
						return res;
				}
			}
			return "NO";
		}catch(Exception e){ return "NO";}
	}
	
	
	private synchronized void send_members(String m){
	//----Envoie la chaîne de caractère m à tous les membres----
		for(Socket s : serveurTCP.members ){
			try{
				PrintWriter pw=new PrintWriter(new OutputStreamWriter(s.getOutputStream()));
				pw.println(m);
				pw.flush();
			}catch(Exception e){del_announces(s.getInetAddress().toString()); continue;}
		}
	}
	
	
	private synchronized String add_announce(String m){
	//----Ajoute une annonce dans la banque de données et préviens les membres connectés----
		try{
			String[] spl = m.split(" ");
			String titre = null, port = null, data = null, id = null,adre = this.socket.getInetAddress().toString();
			int j;
			for(int i=0; i<spl.length; i++){
				j=i;
				if(spl[i].startsWith("TITLE")){
					titre = spl[i].substring(5);
					while(j<=spl.length-2){
						if(spl[j].charAt(spl[j].length()-1) == '\\'){
							titre = titre.substring(0, titre.length()-1) +" "+spl[j+1];
							j++;
						}
						else{i=j;break;}
					}
				}
				
				
				else if(spl[i].startsWith("PORT")){
					port = spl[i].substring(4);
				}
				
				
				else if(spl[i].startsWith("MESSAGE")){
					data = spl[i].substring(7);
					while(j<=spl.length-2){
						if(spl[j].charAt(spl[j].length()-1) == '\\'){
							data = data.substring(0, data.length()-1) +" "+spl[j+1];
							j++;
						}
						else{i=j;break;}
					}
				}
				
			}

			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			messageDigest.update(m.getBytes());
			id = ""+(new String(messageDigest.digest())).hashCode();
			String ann = adre+"%%"+id+"%%"+port+"%%"+titre+"%%"+data;
			serveurTCP.announces.add(ann);
			String ret = "ADD ID"+id+" TITLE"+titre;
			send_members(ret);
			return "OK";
		}catch(Exception e){
			return "";
		}
	}
	
	
	
	
	private synchronized void del_announces(String ad){
	//----Supprime une annonce et préviens les membres connectés----
		try{
			for(String ann : serveurTCP.announces){
				String[] spl = ann.split("%%");
				String adre = spl[0], id = spl[1], port = spl[2], titre = spl[3], data = spl[4];
				if(adre.equals(ad)){
					send_members("DEL ID"+id);
					serveurTCP.announces.remove(ann);
				}
			}
		}catch(Exception e){}
	}
	

	private String read_exec(String m){
	//----Traîtement d'une commande----
		try{
			String[] opt = m.split(" ");
			if(opt[0].equals("GET")){
				return show_announces();
			}
			
			if(opt[0].equals("DES")){
				return des_announce(opt[1].substring(2));
			}
		
			else if(opt[0].equals("NEW")){
				return add_announce(m);
			}
		
			else if(opt[0].equals("CON")){
				//connect_to(m);
				return "NON";
			}
		
			else if(opt[0].equals("HLP")){
				return help();
			}
		
			else{
				return "";
			}
		}catch(Exception e){
			return "NO";
		}
	}



	
	public void run(){
		try{
			BufferedReader br=new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter pw=new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			InetAddress sockAdr = socket.getInetAddress();
			pw.print("HI "+sockAdr+" ! @@"+show_announces()+"\n");
			pw.flush();
			while(true){
				String mess=br.readLine();
				if(mess.equals("BYE") || mess==null){
					pw.flush();
					break;
				}
				String rep = read_exec(mess);
				pw.println(rep);
				pw.flush();
				System.out.println("\nMessage recu : \""+mess+"\"\n(Envoyé par "+sockAdr+")\n");
				
			}
			serveurTCP.disconnect(serveurTCP.members,this);
			del_announces(socket.getInetAddress().toString());
			br.close();
			pw.close();
			socket.close();
		}catch(Exception e){
			serveurTCP.disconnect(serveurTCP.members,this);
			del_announces(socket.getInetAddress().toString());
		}
	}
}
