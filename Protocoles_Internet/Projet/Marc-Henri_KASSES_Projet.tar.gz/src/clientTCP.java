import java.net.*;
import java.io.*;
import java.util.*;

public class clientTCP{
	public static void main(String[] args){
		try{
			Scanner sc = new Scanner(System.in);
			Socket socket;
			if(args.length >2){return;}
			else if(args.length ==1){ socket=new Socket(args[0],7777); }
			else if(args.length == 2){ socket=new Socket(args[0],Integer.parseInt(args[1])); }
			else{
				InetAddress myIA=InetAddress.getLocalHost();
				socket=new Socket(myIA,7777);
			}
			clientTCPReception cR = new clientTCPReception(socket);
			Thread t1 = new Thread(cR);
			/*clientTCPEnvoi cE = new clientTCPEnvoi(socket,t1);
			Thread t2 = new Thread(cE);*/
			t1.start(); //t2.start();
			PrintWriter pw=new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			while(true){
				String sent = sc.nextLine();
				pw.println(sent);
				pw.flush();
				if(sent.equals("BYE") || sent==null){break;}
			}
			pw.close();
			socket.close();
		}
		catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}
	}
}
