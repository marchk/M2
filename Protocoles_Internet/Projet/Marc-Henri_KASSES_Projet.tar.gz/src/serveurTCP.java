import java.net.*;
import java.io.*;
import java.util.*;

public class serveurTCP{
 
 	static ArrayList<Socket> members;
 	static ArrayList<String> announces;
 	static String man;
 	
 	
 	private static void initMan(){
	
		BufferedReader br = null;
		FileReader fr = null;

		try {
			br = new BufferedReader(new FileReader("../Docs/man.txt"));
			String sCurrentLine;
			man = "";

			while ((sCurrentLine = br.readLine()) != null) {
				man += sCurrentLine+"@";
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}	
		}
	}
 	
 	
 	static boolean containsAddr(String adre){
 		for(Socket s : members){
			if(adre.equals(s.getInetAddress().toString())){  return true;  }
 		}
 		return false;
 	}
 	
 	
 	
 	synchronized static void ajoute(String m){
 		announces.add(m);
 	}
 	
	static void connect(ArrayList<Socket> m, Socket ad){
		System.out.println(""+ad.getInetAddress()+" logged in !");
		m.add(ad);
	}
	
	static void disconnect(ArrayList<Socket> m, servThread st){
			m.remove(st.getSocket());
			System.out.println(""+st.getSocket().getInetAddress()+" has left !");
	}

	public static void main(String[] args){
		try{
			initMan();
			announces= new ArrayList<String>();
			members = new ArrayList<Socket>();
			ServerSocket server;
			if(args.length >1){return;}
			else if(args.length==1){ server=new ServerSocket(Integer.parseInt(args[0]));}
			else{ server=new ServerSocket(7777); }
			while(true){
				Socket socket=server.accept();
				connect(members,socket);
				servThread st = new servThread(socket);
				Thread t = new Thread(st);
				t.start();
			}
		}
		catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}
	}
}
